﻿using Sandbox.UI;
public class LayoutBoxInset : Panel
{
}
