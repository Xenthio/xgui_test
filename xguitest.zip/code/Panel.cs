using Sandbox;
using XGUI;

public sealed class OpenMenu : Component
{
	protected override void OnEnabled()
	{
		base.OnEnabled();
	}
	bool hi = true;
	protected override void OnFixedUpdate()
	{
		base.OnFixedUpdate();
		if ( hi && XGUIRootPanel.Current != null )
		{

			XGUIRootPanel.Current.AddChild<MenuTest>();
			hi = false;
		}
	}
}
